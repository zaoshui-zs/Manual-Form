package com.manual.forum;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@SpringBootApplication(scanBasePackages ={"com.manual.forum","com.manual.forum.exception.handler"})
@ComponentScan({"com.manual.forum","com.manual.forum.exception.handler"})
@Configuration
@MapperScan("com.manual.forum.mapper")
public class DemoApplication {

	public static void main(String[] args) throws Exception{
		SpringApplication.run(DemoApplication.class, args);
	}

}
