package com.manual.forum.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.manual.forum.inteceptor.LoginInterceptor;


@Configuration
public class LoginConfig implements WebMvcConfigurer {

//	@Value("${upload.basePath}")
//	private String baseUploadPath;
//	
//	@Value("${images.basePath}")
//	private String baseImagesPath;
	private String basePath ="D:\\Documents\\workspace-spring-tool-suite-4-4.9.0.RELEASE\\demo\\src\\main\\resources\\static\\images\\";
	
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		//注册拦截器
		InterceptorRegistration registration = registry.addInterceptor(new LoginInterceptor());
		registration.addPathPatterns("/**");//所有路径都被拦截
		registration.excludePathPatterns(//添加不拦截路径
				"/index",				//首页
				"/",					//首页
				"",						//首页
				"/login",				//登录路径
				"/user/login",			//登录路径
				"/user/reg",
				"/user/queryUserById",
				"/menu/list",
				"/course",
				"/courseDetail",
				"/comment/list",
				"/comment/refreshComment",
				"/search",
				"/search/course",
				"/search/user",
				"/error",
				"/**/*.html",			//html静态资源
				"/**/*.js",				//js静态资源
				"/**/*.css",			//css静态资源
				"/**/*.jpg",
				"/**/*.png",
				"/test"
				);
	}
	
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		//registry.addResourceHandler("/upload/**").addResourceLocations("file:C:\\Users\\22210003\\Documents\\ManualForum\\src\\main\\resources\\static\\upload");
		//registry.addResourceHandler("/upload/**").addResourceLocations("file:"+baseUploadPath);
		//registry.addResourceHandler("/images/**").addResourceLocations("file:"+baseImagesPath);
		registry.addResourceHandler("/images/**").addResourceLocations("file:"+basePath);
	}
}
