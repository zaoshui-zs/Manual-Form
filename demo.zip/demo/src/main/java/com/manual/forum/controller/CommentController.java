package com.manual.forum.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.ResponseBody;


import com.manual.forum.dto.UserComment;
import com.manual.forum.pojo.Comment;
import com.manual.forum.pojo.User;
import com.manual.forum.pojo.response.CommonResponse;
import com.manual.forum.service.impl.CommentServiceImpl;

@Controller
@RequestMapping(value="/comment")
public class CommentController {
	
	@Autowired
	CommentServiceImpl commentServiceImpl;

	@RequestMapping(value="/addComment",method=RequestMethod.POST)
	@ResponseBody
	public CommonResponse<Comment> AddComment(Comment comment, HttpServletRequest request){
		HttpSession session = request.getSession();
		User u = (User)session.getAttribute("currentUser");
		comment.setUid(u.getId());
		Comment cm = commentServiceImpl.addComment(comment);
		CommonResponse<Comment> result = new CommonResponse<>(cm);
		return result;
		
	}

	@RequestMapping(value="/list",method=RequestMethod.GET)
	@ResponseBody
	public List<UserComment> Comment(String comment_table,Integer comment_row){
		List<UserComment> ucm = commentServiceImpl.getUserCommentList(comment_table, comment_row);
		
		return ucm;
		
	}
	
	@RequestMapping(value="/refreshComment",method= {RequestMethod.POST,RequestMethod.GET})
	public String refreshComment(Model m,String comment_table,Integer comment_row) {
		System.out.println("table="+comment_table+" id="+comment_row);
		List<UserComment> ucm = commentServiceImpl.getUserCommentList(comment_table, comment_row);
		m.addAttribute("ucm", ucm);
		int comment_number = commentServiceImpl.getCommentNumber(comment_table, comment_row);
		m.addAttribute("comment_number", comment_number);
		return "courseDetail::comment_refresh";
	}

}
