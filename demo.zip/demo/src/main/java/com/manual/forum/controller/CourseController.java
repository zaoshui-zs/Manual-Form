package com.manual.forum.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.manual.forum.enums.UploadEnum;
import com.manual.forum.pojo.Course;
import com.manual.forum.pojo.Course_procedure;
import com.manual.forum.pojo.User;
import com.manual.forum.pojo.response.CommonResponse;
import com.manual.forum.service.impl.CourseServiceImpl;
import com.manual.forum.service.impl.CourseProcedureServiceImpl;
import com.manual.forum.util.PhotoUploadUtil;

@RestController
@RequestMapping(value="/course")
public class CourseController{
	
	@Autowired
	CourseServiceImpl courseServiceImpl;
	
	@Autowired
	CourseProcedureServiceImpl cpServiceImpl;
	
	@RequestMapping(value="/uploadCourse1", method=RequestMethod.POST)
	public CommonResponse<Void> uploadCourse1( @RequestParam("uploadPhoto") MultipartFile uploadPhoto,Course course,Course_procedure course_procedure, HttpServletRequest request) throws IOException {

		System.out.println("uploadCourse1:course=="+course);

		PhotoUploadUtil photoUploadUtil = new PhotoUploadUtil();
		String path = photoUploadUtil.uploadPhoto(uploadPhoto,UploadEnum.course.getType());
		course.setPhoto(path);
		
		HttpSession session = request.getSession();
		User user = (User)session.getAttribute("currentUser");
		Integer uid = user.getId();
		course.setUid(uid);
		//session.setAttribute("uploadPhoto", uploadPhoto);
		
		session.setAttribute("course", course);

		CommonResponse<Void> result = new CommonResponse<>();
		return result;
	}

	@RequestMapping(value="/uploadCourse2", method=RequestMethod.POST)
	public CommonResponse<Course> uploadCourse2(String[] procedure_photo,String[] procedure_desc,String tips, HttpServletRequest request) throws IOException {

		System.out.println("desc大小是："+procedure_desc.length);
		System.out.println("文件大小是："+procedure_photo.length);
		HttpSession session = request.getSession();
		
		Course course = (Course)session.getAttribute("course");

		course.setTips(tips);
		courseServiceImpl.addCourse(course);
		
		System.out.println("uploadCourse2:course=="+course);
		
		int course_id = course.getId();
		
		
		
		cpServiceImpl.addCourseProcedureList(procedure_desc, procedure_photo, course_id);
				
		CommonResponse<Course> result = new CommonResponse<>(course);
		session.removeAttribute("course");
		return result;
	}
	
	@RequestMapping(value="/uploadPhoto", method=RequestMethod.POST)
	public CommonResponse<String[]> uploadPhoto(MultipartFile[] uploadFiles) throws IOException {

		int length = uploadFiles.length;
		System.out.println("文件大小是："+length);
		String[] paths = new String[length];
		
		PhotoUploadUtil photoUploadUtil = new PhotoUploadUtil();
		for(int i=0;i<uploadFiles.length;i++) {
			String path = photoUploadUtil.uploadPhoto(uploadFiles[i],UploadEnum.course.getType());
			paths[i] = path;
		}
			
		CommonResponse<String[]> result = new CommonResponse<>(paths);

		return result;
	}
	
}
