package com.manual.forum.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.manual.forum.pojo.Menu;
import com.manual.forum.service.impl.MenuServiceImpl;

@RestController
@RequestMapping("/menu")
public class MenuController {
	@Autowired
	MenuServiceImpl menuServiceImpl;
	
	@RequestMapping("/list")
	public List<Menu> MenuList(Integer uid) {
		List<Menu> menu = menuServiceImpl.getMenuByUid(uid);

		return menu;
	}


}
