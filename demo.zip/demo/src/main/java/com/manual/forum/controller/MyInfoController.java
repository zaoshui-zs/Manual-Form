package com.manual.forum.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.manual.forum.pojo.Course;
import com.manual.forum.pojo.User;
import com.manual.forum.service.impl.CourseServiceImpl;
import com.manual.forum.service.impl.UserServiceImpl;

@Controller
@RequestMapping(value="/MyInfo")
public class MyInfoController {

	@Autowired
	CourseServiceImpl courseServiceImpl;
	
	@Autowired
	UserServiceImpl userServiceImpl;
	
	@RequestMapping(value={"","/myCourse"})
	public String MyCoursePage(Model m,Integer uid,@RequestParam (defaultValue = "0" )Integer pageNum) {
		m.addAttribute("cur",0);
		m.addAttribute("fragment", "course");
		m.addAttribute("controller", "MyInfo/myCourse?uid="+uid);
		User user = userServiceImpl.selectUserById(uid);
		m.addAttribute("user", user);
		System.out.println("MyInfo的user为"+user);
		PageHelper.startPage(pageNum, 8);
		List<Course> courseList = courseServiceImpl.queryAllCourseByUid(uid);
		PageInfo<Course> pageInfo = new PageInfo<Course>(courseList);
		m.addAttribute("pageInfo", pageInfo);
		return "MyInfo";
	}
	
	@RequestMapping(value="/myBlog")
	public String MyBlogPage(Model m,Integer uid,@RequestParam (defaultValue = "0" )Integer pageNum) {
		m.addAttribute("cur",1);
		m.addAttribute("fragment", "blog");
		m.addAttribute("controller", "MyInfo/myBlog");
		User user = userServiceImpl.selectUserById(uid);
		m.addAttribute("user", user);
//		PageHelper.startPage(pageNum, 8);
//		List<Course> courseList = courseServiceImpl.queryAllCourseByUid(uid);
//		PageInfo<Course> pageInfo = new PageInfo<Course>(courseList);
//		m.addAttribute("pageInfo", pageInfo);
		return "MyInfo";
	}
	
	@RequestMapping(value="/myCollectCourse")
	public String MyCollectCoursePage(Model m,Integer uid,@RequestParam (defaultValue = "0" )Integer pageNum) {
		m.addAttribute("cur",2);
		m.addAttribute("fragment", "course");
		m.addAttribute("controller", "MyInfo/myCollectCourse");
		User user = userServiceImpl.selectUserById(uid);
		m.addAttribute("user", user);
		PageHelper.startPage(pageNum, 8);
		List<Course> courseList = courseServiceImpl.getCollectList(uid,"course");
		PageInfo<Course> pageInfo = new PageInfo<Course>(courseList);
		m.addAttribute("pageInfo", pageInfo);
		return "MyInfo";
	}
}
