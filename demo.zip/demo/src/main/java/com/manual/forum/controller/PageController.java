package com.manual.forum.controller;


import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.manual.forum.dto.UserComment;
import com.manual.forum.enums.SexEnum;
import com.manual.forum.pojo.Course;
import com.manual.forum.pojo.Course_procedure;
import com.manual.forum.pojo.User;
import com.manual.forum.pojo.User_collect;
import com.manual.forum.service.impl.CommentServiceImpl;
import com.manual.forum.service.impl.CourseProcedureServiceImpl;
import com.manual.forum.service.impl.CourseServiceImpl;
import com.manual.forum.service.impl.UserServiceImpl;
import com.manual.forum.util.ToMapUtil;

@Controller
public class PageController {
	
	@Autowired
	UserServiceImpl userServiceImpl;
	
	@Autowired
	CourseServiceImpl courseServiceImpl;
	
	@Autowired
	CourseProcedureServiceImpl cpServiceImpl;
	
	@Autowired
	CommentServiceImpl commentServiceImpl;
		
	@RequestMapping(value={"", "/", "/index"})
	public String indexPage(Model m) {	
		//System.out.println("Default charset: " + response.getCharacterEncoding());
		m.addAttribute("cur", 12);
		return "index";
	}
	
	@RequestMapping(value="/login")
	public String loginPage() {	
		System.out.println("loginPage:user=null");
		return "login";
	}
	
	@RequestMapping(value="/logOut")
	public String logOut(HttpServletRequest request) {
		
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("currentUser");
		int id = user.getId();
		userServiceImpl.logout(id);
		session.removeAttribute("currentUser");
		System.out.println("log out");
		return "redirect:index";
	}
	
	@RequestMapping(value="/course")
	public String coursePage(Model m, @RequestParam (defaultValue = "0" )Integer cateId, @RequestParam (defaultValue = "0" )Integer pageNum) {
		//System.out.println("cateId是"+cateId);
		m.addAttribute("cur",cateId);
		PageHelper.startPage(pageNum, 8);
		List<Course> courseList = courseServiceImpl.queryAllCourseByCateId(cateId);
		PageInfo<Course> pageInfo = new PageInfo<Course>(courseList);
		m.addAttribute("pageInfo", pageInfo);
		return "course";
	}
	
	@RequestMapping(value="/courseDetail")
	public String courseDetailPage(Model m, Integer courseId, HttpServletRequest request) {
		HttpSession session = request.getSession();
		User currentUser = (User)session.getAttribute("currentUser");
		Course course = courseServiceImpl.GetCourseById(courseId);
		m.addAttribute("course",course);
		ToMapUtil tmu = new ToMapUtil();
		Map<String, String> materialMap =  tmu.toMap(course.getMaterial_name(), course.getMaterial_num(), ",");
		m.addAttribute("materialMap", materialMap);
		Map<String, String> toolMap =  tmu.toMap(course.getTool_name(), course.getTool_num(), ",");
		m.addAttribute("toolMap", toolMap);
		List<Course_procedure> cpList = cpServiceImpl.GetCourseProcedureListByCid(courseId);
		m.addAttribute("cpList",cpList);
		List<UserComment> ucm = commentServiceImpl.getUserCommentList("course", courseId);
		m.addAttribute("ucm",ucm);
		int comment_number = commentServiceImpl.getCommentNumber("course", courseId);
		m.addAttribute("comment_number", comment_number);
		if(currentUser!=null) {
			Boolean user_collect = userServiceImpl.getCollect(currentUser.getId(), "course", courseId);
			m.addAttribute("user_collect", user_collect);
		}else {
			m.addAttribute("user_collect", false);
		}
		return "courseDetail";
	}
	@RequestMapping(value="/refreshCollect")
	public String refreshCollect(Model m, User_collect user_collect, HttpServletRequest request) {
		HttpSession session = request.getSession();
		User currentUser = (User)session.getAttribute("currentUser");
		if(currentUser!=null) {
			Boolean res = userServiceImpl.getCollect(currentUser.getId(), user_collect.getCollect_table(), user_collect.getCollect_id());
			m.addAttribute("user_collect", res);
		}else {
			m.addAttribute("user_collect", false);
		}
		return "courseDetail::user_collect";
	}

	@RequestMapping(value="/uploadCourse")
	public String uploadCoursePage() {		
		return "uploadCourse";
	}
	
	@RequestMapping(value="/uploadCourse2")
	public String uploadCourse2Page() {		
		return "uploadCourse2";
	}
	@RequestMapping(value="/modifyUserInfo")
	public String modifyUserInfo(Model m, Integer uid) {
		User user = userServiceImpl.selectUserById(uid);
		m.addAttribute("user", user);
		m.addAttribute("SexEnum", SexEnum.values());
		return "modifyUserInfo";
	}
	@RequestMapping(value="/test")
	public String test() {
		return "test";
	}
	
}
