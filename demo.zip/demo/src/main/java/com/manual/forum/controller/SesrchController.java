package com.manual.forum.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.manual.forum.pojo.Course;
import com.manual.forum.pojo.User;
import com.manual.forum.service.impl.CourseServiceImpl;
import com.manual.forum.service.impl.UserServiceImpl;

@Controller
@RequestMapping("/search")
public class SesrchController {

	@Autowired
	CourseServiceImpl courseServiceImpl;
	
	@Autowired
	UserServiceImpl userServiceImpl;
	
	@RequestMapping(value={"","/course"})
	public String search(Model m, String searchText,@RequestParam (defaultValue = "0" )Integer pageNum) {
		m.addAttribute("cur",0);
		m.addAttribute("fragment", "course");
		m.addAttribute("controller", "search/course?searchText="+searchText);
		m.addAttribute("searchText", searchText);
		PageHelper.startPage(pageNum, 8);
		String searchSQL = '%'+searchText+'%';
		List<Course> courseList = courseServiceImpl.search(searchSQL);
		PageInfo<Course> pageInfo = new PageInfo<Course>(courseList);
		m.addAttribute("pageInfo", pageInfo);

		PageHelper.startPage(pageNum, 8);
		List<User> userList = userServiceImpl.search(searchSQL);
		PageInfo<User> pageInfo2 = new PageInfo<User>(userList);
		m.addAttribute("pageInfo2", pageInfo2);
		return "search";
	}
	
	@RequestMapping(value="/user")
	public String searchUser(Model m, String searchText,@RequestParam (defaultValue = "0" )Integer pageNum) {
		m.addAttribute("cur",1);
		m.addAttribute("fragment", "user");
		m.addAttribute("controller", "search/user?searchText="+searchText);
		m.addAttribute("searchText", searchText);
		String searchSQL = '%'+searchText+'%';
		PageHelper.startPage(pageNum, 8);
		List<User> userList = userServiceImpl.search(searchSQL);
		PageInfo<User> pageInfo = new PageInfo<User>(userList);
		m.addAttribute("pageInfo", pageInfo);
		return "search";
	}
}
