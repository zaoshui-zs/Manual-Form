package com.manual.forum.controller;


import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.manual.forum.enums.CommonResponseEnum;
import com.manual.forum.enums.UploadEnum;
import com.manual.forum.pojo.User;
import com.manual.forum.pojo.User_collect;
import com.manual.forum.pojo.response.CommonResponse;
import com.manual.forum.service.impl.UserServiceImpl;
import com.manual.forum.util.PhotoUploadUtil;


@RestController
@RequestMapping(value="/user")
public class UserController{
	
	@Autowired
	UserServiceImpl userServiceImpl;
	
	@RequestMapping(value="/queryUserById")
	public CommonResponse<User> query(int id) {
		System.out.println("==queryUserById==");
		User user = userServiceImpl.selectUserById(id);
		System.out.println("user==="+user);
		CommonResponse<User> result = new CommonResponse<>(user);
		//System.out.println("result==="+result);
		return result;
	}
	
	@RequestMapping("/addUser")
	public CommonResponse<User> addUser(User user) {
		User u = userServiceImpl.addUser(user);
		CommonResponse<User> result = new CommonResponse<>(u);
		return result;
	}
	
	@PostMapping(value="/reg")
	public CommonResponse<User> register(User user) {
		User u = userServiceImpl.register(user);
		CommonResponse<User> result = new CommonResponse<>(u);
		return result;
	}
	
	@RequestMapping(value="/login")
	public CommonResponse<User> login(String username, String password, HttpServletRequest request) {
		HttpSession session = request.getSession();
		User u = userServiceImpl.login(username, password);
		u.setAccess(userServiceImpl.getAdminAccess(u.getId()));
		session.setAttribute("currentUser", u);
		CommonResponse<User> result = new CommonResponse<>(u);
		System.out.println("登录成功");
		return result;
	}
	
	@RequestMapping(value="/modifyUserInfo")
	public CommonResponse<Integer> modifyUserInfo(User user,MultipartFile iconPhoto,HttpServletRequest request) throws IOException{
		HttpSession session = request.getSession();
		User u = userServiceImpl.selectUserById(user.getId());
		System.out.println("修改前的user"+u);
		PhotoUploadUtil photoUploadUtil = new PhotoUploadUtil();
		String path = photoUploadUtil.uploadPhoto(iconPhoto,UploadEnum.icon.getType());
		if(path.trim().length()==0) {
			System.out.println("path为空，path="+path);
			user.setIcon(u.getIcon());
		}else {
			System.out.println("path不为空，path="+path);
			user.setIcon(path);
		}

		userServiceImpl.updateUserInfo(user);
		u = userServiceImpl.selectUserById(user.getId());
		System.out.println("修改后的user"+u);
		session.setAttribute("currentUser", u);
		CommonResponse<Integer> result = new CommonResponse<>(user.getId());
		return result;
	}
	@RequestMapping(value="/modifyPassword")
	public CommonResponse<Integer> modifyPwd(Integer id,String cur_password,String new_password,String v_password,HttpServletRequest request){
		HttpSession session = request.getSession();
		
		User u = userServiceImpl.selectUserById(id);
		System.out.println("修改前的user"+u);
		CommonResponseEnum.PASSWORD_NOT.assertEquals(cur_password, u.getPassword());
		CommonResponseEnum.PASSWORD_NOT.assertEquals(v_password, new_password);
		userServiceImpl.updatePassword(new_password,id);
		u = userServiceImpl.selectUserById(id);
		System.out.println("修改后的user"+u);
		session.setAttribute("currentUser", u);
		CommonResponse<Integer> result = new CommonResponse<>(id);
		return result;
	}
	@RequestMapping(value="/modifyPhone")
	public CommonResponse<Integer> modifyPhone(Integer id,String cur_phone,String new_phone,HttpServletRequest request){
		HttpSession session = request.getSession();
		
		User u = userServiceImpl.selectUserById(id);
		System.out.println("修改前的user"+u);
		CommonResponseEnum.PASSWORD_NOT.assertEquals(cur_phone, u.getPhone());
		userServiceImpl.updatePhone(new_phone,id);
		u = userServiceImpl.selectUserById(id);
		System.out.println("修改后的user"+u);
		session.setAttribute("currentUser", u);
		CommonResponse<Integer> result = new CommonResponse<>(id);
		return result;
	}
	
	@RequestMapping(value="/collect", method=RequestMethod.POST)
	public CommonResponse<Void> collect(User_collect user_collect) {

		System.out.println("user_collect=="+user_collect);
		
		userServiceImpl.collect(user_collect);
				
		CommonResponse<Void> res = new CommonResponse<>();

		return res;
	}

	@RequestMapping(value="/cancelCollect", method=RequestMethod.POST)
	public CommonResponse<Void> cancelCollect(User_collect user_collect) {

		System.out.println("user_collect=="+user_collect);
		
		userServiceImpl.cancelCollect(user_collect);
				
		CommonResponse<Void> res = new CommonResponse<>();

		return res;
	}

}
