package com.manual.forum.controller.admin;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.manual.forum.pojo.Menu;
import com.manual.forum.pojo.User;
import com.manual.forum.service.impl.MenuServiceImpl;

@Controller
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	MenuServiceImpl menuServiceImpl;
	
	@RequestMapping(value={""})
	public String admin(Model m, HttpServletRequest request) {
		User user = (User)request.getSession().getAttribute("currentUser");
		List<Menu> menu = menuServiceImpl.getMenuByUid(user.getId());
		m.addAttribute("menus", menu);
		return "admin/Admin_Main";
	}
	
}
