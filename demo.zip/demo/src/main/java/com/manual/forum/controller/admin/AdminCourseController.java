package com.manual.forum.controller.admin;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.manual.forum.pojo.Course;
import com.manual.forum.pojo.Menu;
import com.manual.forum.pojo.User;
import com.manual.forum.service.impl.CourseServiceImpl;
import com.manual.forum.service.impl.MenuServiceImpl;

@Controller
@RequestMapping("/admin/course")
public class AdminCourseController {
	@Autowired
	CourseServiceImpl courseServiceImpl;
	
	@Autowired
	MenuServiceImpl menuServiceImpl;
	
	@RequestMapping("/list")
	public String list(Model m, HttpServletRequest request,@RequestParam (defaultValue = "0" )Integer pageNum) {
		//System.out.println("cateId是"+cateId);
		User user = (User)request.getSession().getAttribute("currentUser");
		List<Menu> menu = menuServiceImpl.getMenuByUid(user.getId());
		m.addAttribute("menus", menu);
		PageHelper.startPage(pageNum, 8);
		List<Course> courseList = courseServiceImpl.queryAllCourse();
		PageInfo<Course> pageInfo = new PageInfo<Course>(courseList);
		m.addAttribute("pageInfo", pageInfo);
		return "admin/Admin_CourseList";
	}

}
