package com.manual.forum.dto;

import lombok.Data;

@Data
public class CategoryNum {

	private Integer id;
	private String category;
	private String icon;
	private Integer num;
}
