package com.manual.forum.dto;

import lombok.Data;

@Data
public class ColumnComment {
	private String column;
	private String comment;
}
