package com.manual.forum.dto;

import java.util.Date;
import java.util.List;

import lombok.Data;
@Data
public class UserComment {
	private Integer id;
	private String content;
	private Integer uid;
	private String username;
	private String icon;
	private Integer parent_id;
	private Date create_time;
	private String comment_table;
	private Integer comment_row;
	private List<UserComment> child;
}
