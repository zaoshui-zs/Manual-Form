package com.manual.forum.enums;

import com.manual.forum.exception.assertion.CommonExceptionAssert;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ArgumentResponseEnum implements CommonExceptionAssert{
	/**
     * 绑定参数校验异常
     */
    VALID_ERROR(6000, "参数校验异常"),
    EMPTY_ARGS(6001,"参数为空"),
    ;

    /**
     * 返回码
     */
    private int code;
    /**
     * 返回消息
     */
    private String message;

}
