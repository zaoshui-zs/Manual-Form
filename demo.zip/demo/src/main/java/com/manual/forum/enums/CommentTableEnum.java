package com.manual.forum.enums;

public enum CommentTableEnum {
	course,
	circle_blog;
	

}



    


