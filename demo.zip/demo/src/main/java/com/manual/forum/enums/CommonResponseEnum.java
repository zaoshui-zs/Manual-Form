package com.manual.forum.enums;


import com.manual.forum.exception.BaseException;
import com.manual.forum.exception.assertion.BusinessExceptionAssert;
import com.manual.forum.pojo.response.BaseResponse;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum CommonResponseEnum implements BusinessExceptionAssert {

    SUCCESS(2000, "SUCCESS"),
    USERNAME_DUPLICATE(2002,"用户名被占用"),
    USERNAME_NOT_FOUND(2003,"用户名找不到"),
    PASSWORD_NOT(2004,"密码错误"),
    CONTENT_NOT_NULL(2005,"内容不能为空"),
    ADMIN_NOT(2006,"无管理员身份"),
    /**
     * 服务器繁忙，请稍后重试
     */
    SERVER_BUSY(9998, "服务器繁忙"),
    /**
     * 服务器异常，无法识别的异常，尽可能对通过判断减少未定义异常抛出
     */
    SERVER_ERROR(9999, "网络异常"),
    
    ;

    /**
     * 返回码
     */
    private int code;
    /**
     * 返回消息
     */
    private String message;

    /**
     * 校验返回结果是否成功
     * @param response 远程调用的响应
     */
    public static void assertSuccess(BaseResponse response) {
        SERVER_ERROR.assertNotNull(response);
        int code = response.getCode();
        if (CommonResponseEnum.SUCCESS.getCode() != code) {
            String msg = response.getMessage();
            throw new BaseException(code, msg);
        }
    }
}
