package com.manual.forum.enums;

public interface IResponseEnum {
	int getCode();
	String getMessage();
}
