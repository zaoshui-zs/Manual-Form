package com.manual.forum.enums;

import lombok.Getter;

@Getter
public enum SexEnum {
	male("男"),female("女");
	
	private String sex;
	
	SexEnum(String sex) {
		// TODO Auto-generated constructor stub
		this.sex = sex;
	}
	public static String getSexName(SexEnum sex) {
		for(SexEnum s : SexEnum.values()) {
			if(s == sex) {
				return s.getSex();
			}
		}
		return null;
	}
	
}
