package com.manual.forum.enums;

import lombok.Getter;

@Getter
public enum UploadEnum {

	course("course"),
	blog("blog"),
	icon("icon");
	
	private String type;
	
	UploadEnum(String type){
		this.type = type;
	}
}
