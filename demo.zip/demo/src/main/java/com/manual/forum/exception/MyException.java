package com.manual.forum.exception;

import com.manual.forum.enums.CommonResponseEnum;

import lombok.Getter;

@Getter
public class MyException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer code;
	
	public MyException(Integer code, String message){
		super(message);
		this.code = code;
	}

	public MyException(CommonResponseEnum responseEnum){
		super(responseEnum.getMessage());
		this.code = responseEnum.getCode();
	}


	@Override
	public String toString() {
		return "MyException{" +
				"code=" + code +
				", message=" + this.getMessage() +
				'}';
	}
}
