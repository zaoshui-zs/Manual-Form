package com.manual.forum.exception;

public class WrapMessageException extends RuntimeException{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public WrapMessageException(String message) {
        super(message);
    }

    public WrapMessageException(String message, Throwable cause) {
        super(message, cause);
    }
}
