package com.manual.forum.exception.assertion;

import java.text.MessageFormat;

import com.manual.forum.enums.IResponseEnum;
import com.manual.forum.exception.BaseException;
import com.manual.forum.exception.BusinessException;

public interface BusinessExceptionAssert extends IResponseEnum, Assert {

    @Override
    default BaseException newException(Object... args) {
        String msg = MessageFormat.format(this.getMessage(), args);
 
        return new BusinessException(this, args, msg);
    }

    @Override
    default BaseException newException(Throwable t, Object... args) {
        String msg = MessageFormat.format(this.getMessage(), args);

        return new BusinessException(this, args, msg, t);
    }

}