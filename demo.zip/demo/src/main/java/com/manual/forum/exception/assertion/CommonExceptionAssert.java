package com.manual.forum.exception.assertion;

import java.text.MessageFormat;

import com.manual.forum.enums.IResponseEnum;
import com.manual.forum.exception.ArgumentException;
import com.manual.forum.exception.BaseException;

import cn.hutool.core.util.ArrayUtil;

public interface CommonExceptionAssert extends IResponseEnum, Assert {

	@Override
    default BaseException newException(Object... args) {
        String msg = this.getMessage();
        if (ArrayUtil.isNotEmpty(args)) {
            msg = MessageFormat.format(this.getMessage(), args);
        }

        return new ArgumentException(this, args, msg);
    }

    @Override
    default BaseException newException(Throwable t, Object... args) {
        String msg = this.getMessage();
        if (ArrayUtil.isNotEmpty(args)) {
            msg = MessageFormat.format(this.getMessage(), args);
        }

        return new ArgumentException(this, args, msg, t);
    }
}
