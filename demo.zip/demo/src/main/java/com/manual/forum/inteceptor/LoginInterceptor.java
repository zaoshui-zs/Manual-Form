package com.manual.forum.inteceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.manual.forum.exception.BusinessException;
import com.manual.forum.pojo.User;

/**
 * 登录拦截器
 * @author lyq
 *
 */
public class LoginInterceptor implements HandlerInterceptor{
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object Handler) throws BusinessException{
		try {
			HttpSession session = request.getSession();
			//判断用户
			User user = (User)session.getAttribute("currentUser");
			if(user != null) {
				//System.out.println("request-url=="+request.getRequestURL().indexOf("admin"));
				if(request.getRequestURL().indexOf("admin")!=-1) {
					//试图访问管理员界面
					System.out.println("访问管理员界面"+user.getId());
					
					if(user.getAccess()==1) {
						//是管理员身份
						System.out.println("管理员");
						return true;
					}else {
						System.out.println("不是管理员");
						response.sendRedirect(request.getContextPath()+"/error");
						return false;
					}
				}else {
					System.out.println("拦截器--返回true");
					return true;
				}
				
			}
			System.out.println("拦截器---没登录，跳转登录"+request.getContextPath()+"/login");
	
			response.sendRedirect(request.getContextPath()+"/login");
		}catch(Exception e) {
			
			e.printStackTrace();
		}
		System.out.println("拦截器--返回false");
		return false;
	}
	
	 /***
     * 请求处理之后进行调用，但是在视图被渲染之前（Controller方法调用之后）
     */
    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        System.out.println("执行了拦截器的postHandle方法");
    }

    /***
     * 整个请求结束之后被调用，也就是在DispatchServlet渲染了对应的视图之后执行（主要用于进行资源清理工作）
     */
    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        System.out.println("执行了拦截器的afterCompletion方法");
    }
	

}
