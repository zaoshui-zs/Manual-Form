package com.manual.forum.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface BlogMapper {

	@Select("select count(*) as num from circle_blog where uid = #{uid}")
	int getBlogNumberByUid(Integer uid);
}
