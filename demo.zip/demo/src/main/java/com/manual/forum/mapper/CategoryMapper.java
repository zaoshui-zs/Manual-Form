package com.manual.forum.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.manual.forum.dto.CategoryNum;
import com.manual.forum.pojo.Course_category;

@Mapper
public interface CategoryMapper {
	
	@Select("select * from course_category order by sort ASC")
	List<Course_category> GetAllCategory();
	
	@Select("select cc.id as 'id', cc.name as 'category', IFNULL(COUNT(c.id),0) as 'num' from course_category cc left join course c on (cc.id = c.category_id) group by cc.id")
	List<CategoryNum> GetAllCategoryAndNum();
	
	@Insert("insert into course_category (name, sort, icon) values(#{cate.name}, #{cate.sort}, #{cate.icon})")
	@Options(useGeneratedKeys=true, keyColumn="id", keyProperty="cate.id")
	void InsertCategory(@Param("cate")Course_category cate);
	
	@Select("select cc.id as 'id', cc.name as 'category',cc.icon as 'icon', IFNULL(COUNT(c.id),0) as 'num' from course_category cc left join course c on (cc.id = c.category_id) group by cc.id order by num desc limit 6")
	List<CategoryNum> GetPopularCategory();
}
