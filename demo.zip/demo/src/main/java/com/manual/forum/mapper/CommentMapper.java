package com.manual.forum.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.manual.forum.dto.UserComment;
import com.manual.forum.pojo.Comment;

@Mapper
public interface CommentMapper {
	@Insert("insert into comment (content,uid,parent_id,create_time,comment_table,comment_row) values (#{content},#{uid},#{parent_id},#{create_time},#{comment_table},#{comment_row})")
	@Options(useGeneratedKeys = true, keyProperty = "id")
	public int addComment(Comment comment);
	
	@Select("select c.*,u.username,u.icon from comment c,user u where c.comment_table = #{table} and c.comment_row = #{table_id} and c.uid = u.id order by c.create_time desc")
	public List<UserComment> GetUserCommentListByTableId(String table,Integer table_id);
	
	@Update("update ${table} set comment_number = comment_number+#{comment_number} where id=#{table_id}")
	int UpdateCommentNumber(String table,Integer table_id,int comment_number);
	
	@Select("select count(*) as comment_number from comment where comment_table=#{table} and comment_row = #{table_id}")
	int getCommentNumber(String table,Integer table_id);
}
