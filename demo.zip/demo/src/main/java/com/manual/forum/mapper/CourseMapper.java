package com.manual.forum.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.manual.forum.pojo.Course;

@Mapper
public interface CourseMapper {
	
	@Insert("Insert into course (category_id,title,abstrs,photo,uid,create_time,tips,material_name,material_num,tool_name,tool_num) values(#{c.category_id},#{c.title},#{c.abstrs},#{c.photo},#{c.uid},#{c.create_time},#{c.tips},#{c.material_name},#{c.material_num},#{c.tool_name},#{c.tool_num})")
	@Options(useGeneratedKeys = true, keyProperty = "id")
	int addCourse(@Param("c")Course course);
	
	@Select("select * from course where category_id = #{cateId}")
	List<Course> queryAllCourseByCateId(Integer cateId);
	
	@Select("select * from course where uid = #{uid} order by create_time desc")
	List<Course> queryAllCourseByUid(Integer uid);
	
	@Select("select * from course")
	List<Course> queryAllCourse();
	
	@Select("select count(*) as num from course where uid = #{uid}")
	int queryCourseNumberByUid(Integer uid);
	
	@Select("select * from course order by create_time desc limit 4")
	List<Course> getRecentCourse();
	
	@Select("select * from course where id = #{id}")
	Course GetCourseById(Integer id);
	
	@Update("update course set comment_number = comment_number+#{comment_number} where id=#{course_id}")
	int UpdateCourseComment(Integer course_id,int comment_number);
	
	@Select("select * from ${collect_table} where id in(select collect_id from user_collect where uid=#{uid} and collect_table=#{collect_table})")
	List<Course> getCollectList(Integer uid,String collect_table);

	@Select("select * from course where title like #{searchText} or abstrs like #{searchText}")
	List<Course> search(String searchText);
	
}
