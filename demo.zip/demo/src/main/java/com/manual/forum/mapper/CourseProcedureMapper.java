package com.manual.forum.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.manual.forum.pojo.Course_procedure;

@Mapper
public interface CourseProcedureMapper {

	@Insert("Insert into course_procedure (course_id,procedure_no,procedure_desc,procedure_photo) values(#{cp.course_id},#{cp.procedure_no},#{cp.procedure_desc},#{cp.procedure_photo})")
	@Options(useGeneratedKeys = true, keyProperty = "id")
	int addCourseProcedure(@Param("cp")Course_procedure cp);
	
	@Select("select * from course_procedure where course_id = #{course_id} order by procedure_no asc")
	List<Course_procedure> getCourseProcedureListByCid(Integer course_id);
}
