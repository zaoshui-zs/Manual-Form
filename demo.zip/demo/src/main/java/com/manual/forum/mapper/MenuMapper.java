package com.manual.forum.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.manual.forum.pojo.Menu;

@Mapper
public interface MenuMapper {

	@Select("select m.* from menu m where m.id in "
			+ "(select menu_id from role_menu where role_id in "
			+ "(select role_id from user_role where uid=#{uid}));")
	List<Menu> getMenuByUid(Integer uid);
}
