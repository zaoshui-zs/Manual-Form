package com.manual.forum.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.manual.forum.pojo.Log_detail;

@Mapper
public interface OperationLogDetailMapper {

	public static class OperationLogDetailMapperProvider{
		public String insertOperationLogDetailSQL(Map<String, List<Log_detail>> map) {
			List<Log_detail> ops = map.get("ops");
			StringBuilder sqlBuild = new StringBuilder("INSERT INTO log_detail (op_log_id,clm_name,clm_comment,old_string,new_string) VALUES");
			for(int i = 0; i < ops.size(); i++) {
				Log_detail o = ops.get(i);
				if(i==0) {
					sqlBuild.append(" ('" + o.getOp_log_id() + "','" + o.getClm_name() +"','" + o.getClm_comment()+"','"+o.getOld_string()+"','" + o.getNew_string()+"') ");
				}else {
					sqlBuild.append(" ,('" + o.getOp_log_id() + "','"+o.getClm_name() +"','" + o.getClm_comment() +"','"+o.getOld_string()+"','"+o.getNew_string()+"') ");
				}
			}
			return sqlBuild.toString();
		}
	}
	//批量添加操作详情
	@InsertProvider(type=OperationLogDetailMapperProvider.class, method="insertOperationLogDetailSQL")
	void insertOperationLogDetail(@Param("ops")List<Log_detail> opds);

}
