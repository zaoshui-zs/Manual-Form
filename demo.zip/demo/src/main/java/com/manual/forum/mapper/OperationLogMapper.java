package com.manual.forum.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectProvider;

import com.manual.forum.dto.ColumnComment;
import com.manual.forum.pojo.Op_log;

@Mapper
public interface OperationLogMapper {

	public static class OperationLogMapperProvider{
		public String selectAnyTalbeSQL(Map<String,String> map) {
			return map.get("sql");
		}
	}
	//查询任意表的字段与备注
	@Select("SELECT COLUMN_NAME `column`,column_comment `comment` FROM INFORMATION_SCHEMA.Columns WHERE table_name=#{table} AND table_schema='db_forum_sys';")
	public List<ColumnComment> selectColumnCommentByTable(@Param("table")String logTable);
	
	//查询任意sql
	@SelectProvider(type=OperationLogMapperProvider.class, method="selectAnyTalbeSQL")
	public Map<String, Object> selectAnyTable(@Param("sql")String string);

	//添加操作日志
	@Insert("INSERT INTO op_log (name, table_name, table_id, uid, optor_name, op_type, op_time) VALUES (#{op.name},#{op.table_name}, #{op.table_id}, #{op.uid},#{op.optor_name}, #{op.op_type}, #{op.op_time});")
	@Options(useGeneratedKeys=true, keyColumn="id", keyProperty="op.id")
	void insertOperationLog(@Param("op")Op_log op);

}
