package com.manual.forum.mapper;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.manual.forum.pojo.Role;
import com.manual.forum.pojo.User;
import com.manual.forum.pojo.User_collect;


@Mapper
public interface UserMapper {

	@Select("select * from user where id = #{id}")
	User selectUserById(int id);
	
	@Select("select * from user where username = #{username}")
	User selectUserByName(String username);
	
	@Insert("insert into user (username,password,phone,gen_time) values (#{username},#{password},#{phone},#{gen_time})")
	@Options(useGeneratedKeys = true, keyProperty = "id")
	public int addUser(User user);

	@Update("update user set username=#{u.username},password=#{u.password},phone=#{u.phone},icon=#{u.icon},sex=#{u.sex},address=#{u.address},level=#{u.level},last_login_time=#{u.last_login_time},gen_time=#{u.gen_time},login_time=#{u.login_time} where id=#{u.id}")
	public int updateUser(@Param("u")User user);
	
	@Update("update user set username=#{u.username},icon=#{u.icon},sex=#{u.sex},address=#{u.address} where id=#{u.id}")
	public int updateUserInfo(@Param("u")User user);
	
	@Update("update user set password=#{p} where id=#{id}")
	public int updatePassword(@Param("p")String password,Integer id);
	
	@Update("update user set phone=#{p} where id=#{id}")
	public int updatePhone(@Param("p")String phone,Integer id);
	
	@Update("update user set login_time=#{login_time} where id=#{id}")
	public int updateLoginTimeById(@Param("login_time")Date login_time, int id);
	
	@Update("update user set last_login_time=#{last_login_time} where id=#{id}")
	public int updateLastLoginTimeById(@Param("last_login_time")Date last_login_time, int id);	
	
	@Select("select username from user where id=#{id}")
	public String getUserNameById(Integer id);

	@Insert("insert into user_collect (uid,collect_id,collect_table,create_time) values(#{uc.uid},#{uc.collect_id},#{uc.collect_table},#{uc.create_time})")
	@Options(useGeneratedKeys = true, keyProperty = "id")
	int collect(@Param("uc")User_collect user_collect);
	
	@Select("select * from user_collect where uid=#{uid} and collect_id = #{collect_id} and collect_table=#{collect_table}")
	User_collect getCollect(Integer uid,String collect_table,Integer collect_id);
	
	@Delete("delete from user_collect where uid=#{uc.uid} and collect_id = #{uc.collect_id} and collect_table=#{uc.collect_table}")
	int cancelCollect(@Param("uc")User_collect user_collect);

	@Select("select * from user where username like #{searchText}")
	List<User> search(String searchText);
	
	@Select("SELECT r.* FROM user_role ur,role r where ur.uid=#{uid} and ur.role_id = r.id;")
	List<Role> getUserRole(Integer uid);

	@Select("select count(*) as num from user_role where uid=#{uid}")
	int getAdminAccess(Integer uid);
}
