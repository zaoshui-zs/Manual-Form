package com.manual.forum.pojo;

import lombok.Data;

@Data
public class Blog_photo {
	private Integer id;
	private Integer circle_blog_id;
	private String photo;
}
