package com.manual.forum.pojo;

import java.util.Date;

import lombok.Data;

@Data
public class Circle {
	private Integer id;
	private String name;
	private String photo;
	private String abstr;
	private Date create_time;
}
