package com.manual.forum.pojo;

import java.util.Date;

import lombok.Data;

@Data
public class Circle_blog {
	private Integer id;
	private Integer uid;
	private String content;
	private Integer circle_id;
	private Date create_time;
	private Integer view_number;
	private Integer star_number;
	private Integer comment_number;
	private Integer collect_number;
}
