package com.manual.forum.pojo;

import lombok.Data;

@Data
public class Circle_user {
	private Integer id;
	private Integer uid;
	private Integer circle_id;
	private Integer role_id;
}
