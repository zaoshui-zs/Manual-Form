package com.manual.forum.pojo;

import java.util.Date;

import lombok.Data;

@Data
public class Comment {
	private Integer id;
	private String content;
	private Integer uid;
	private Integer parent_id;
	private Date create_time;
	private String comment_table;
	private Integer comment_row;
}
