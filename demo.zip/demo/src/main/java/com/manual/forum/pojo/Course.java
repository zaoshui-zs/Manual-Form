package com.manual.forum.pojo;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class Course {
	private Integer id;
	private Integer category_id;
	private String title;
	private String abstrs;
	private String photo;
	private Integer uid;
	private Integer view_number;
	private Integer star_number;
	private Integer comment_number;
	private Integer collect_number;
	
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date create_time;
	private String tips;
	private String material_name;
	private String material_num;
	private String tool_name;
	private String tool_num;
}
