package com.manual.forum.pojo;

import lombok.Data;

@Data
public class Course_category {
	private Integer id;
	private String name;
	private Integer sort;
	private String icon;
}
