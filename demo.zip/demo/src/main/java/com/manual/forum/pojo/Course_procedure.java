package com.manual.forum.pojo;

import lombok.Data;

@Data
public class Course_procedure {
	private Integer id;
	private Integer course_id;
	private Integer procedure_no;
	private String procedure_desc;
	private String procedure_photo;
}
