package com.manual.forum.pojo;

import lombok.Data;

@Data
public class Log_detail {
	private Integer id;
	private Integer op_log_id;
	private String clm_name;
	private String clm_comment;
	private String old_string;
	private String new_string;
}
