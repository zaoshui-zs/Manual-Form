package com.manual.forum.pojo;

import java.util.List;

import lombok.Data;

@Data
public class Menu {
	private Integer id;
	private Integer parent_id;
	private String name;
	private String url;
	private String icon;
	List<Menu> child;
}
