package com.manual.forum.pojo;

import java.util.Date;

import com.manual.forum.enums.OpTypeEnum;

import lombok.Data;

@Data
public class Op_log {
	private Integer id;
	private String name;
	private String table_name;
	private String table_id;
	private Integer uid;
	private String optor_name;
	private OpTypeEnum op_type;
	private Date op_time;
}
