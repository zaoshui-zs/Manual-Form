package com.manual.forum.pojo;

import lombok.Data;

@Data
public class Role {
	private Integer id;
	private String name;
	private String remark;
}
