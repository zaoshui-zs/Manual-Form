package com.manual.forum.pojo;

import lombok.Data;

@Data
public class Role_menu {
	private Integer id;
	private Integer role_id;
	private Integer menu_id;
}
