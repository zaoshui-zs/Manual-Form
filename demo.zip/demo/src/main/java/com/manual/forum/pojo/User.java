package com.manual.forum.pojo;

import java.util.Date;

import com.manual.forum.enums.SexEnum;

import lombok.Data;

@Data
public class User {
	private Integer id;
	private String username;
	private String password;	
	private String phone;	
	private String icon;
	private SexEnum sex;
	private String address;
	private Integer level;
	private Date login_time;
	private Date last_login_time;
	private Date gen_time;
	private int access;
}
