package com.manual.forum.pojo;

import java.util.Date;

import lombok.Data;

@Data
public class User_collect {
	private Integer id;
	private Integer uid;
	private Integer collect_id;
	private String collect_table;
	private Date create_time;
}
