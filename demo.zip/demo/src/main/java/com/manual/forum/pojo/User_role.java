package com.manual.forum.pojo;

import lombok.Data;

@Data
public class User_role {
	private Integer id;
	private Integer role_id;
	private Integer uid;
}
