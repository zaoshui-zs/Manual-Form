package com.manual.forum.pojo.response;

import com.manual.forum.enums.CommonResponseEnum;
import com.manual.forum.enums.IResponseEnum;

import lombok.Data;

@Data
public class BaseResponse {

	protected int code;
	protected String message;
	
	public BaseResponse() {
		this(CommonResponseEnum.SUCCESS);
	}
	public BaseResponse(IResponseEnum responseEnum) {
        this(responseEnum.getCode(), responseEnum.getMessage());
    }

    public BaseResponse(int code, String message) {
        this.code = code;
        this.message = message;
    }


}
