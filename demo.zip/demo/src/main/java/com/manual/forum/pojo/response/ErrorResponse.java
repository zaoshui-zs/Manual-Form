package com.manual.forum.pojo.response;

public class ErrorResponse extends BaseResponse{

    public ErrorResponse() {
    	super();
    }

    public ErrorResponse(int code, String message) {
        super(code, message);
    }
}
