package com.manual.forum.service;

public interface BlogService {

	int getBlogNumberByUid(Integer uid);
}
