package com.manual.forum.service;

import java.util.List;

import com.manual.forum.dto.UserComment;
import com.manual.forum.pojo.Comment;

public interface CommentService {

	public Comment addComment(Comment comment);
	
	public List<UserComment> getUserCommentList(String table,Integer table_id);
	
	public int getCommentNumber(String table,Integer table_id);
}
