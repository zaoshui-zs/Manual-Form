package com.manual.forum.service;

import java.util.List;

import com.manual.forum.dto.CategoryNum;
import com.manual.forum.pojo.Course_category;

public interface CourseCategoryService {

	public List<Course_category> GetAllCategory();
	
	public List<CategoryNum> GetAllCategoryAndNum();
	
	public List<CategoryNum> GetPopularCategory();
}
