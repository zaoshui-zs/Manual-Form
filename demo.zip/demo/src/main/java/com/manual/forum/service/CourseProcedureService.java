package com.manual.forum.service;

import java.util.List;

import com.manual.forum.pojo.Course_procedure;

public interface CourseProcedureService {
	
	int addCourseProcedure(Course_procedure cp);
	/**
	 * 
	 * @param cpd course_procedure_desc
	 * @param cpp course_procedure_photo
	 * @param course_id
	 * @return
	 */
	int addCourseProcedureList(String[] cpd,String[] cpp,Integer course_id);
	
	List<Course_procedure> GetCourseProcedureListByCid(Integer course_id);
}
