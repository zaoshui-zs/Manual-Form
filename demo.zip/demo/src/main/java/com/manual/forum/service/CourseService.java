package com.manual.forum.service;

import java.util.List;
import com.manual.forum.pojo.Course;

public interface CourseService {
	
	int addCourse(Course course);
	
	Course GetCourseById(Integer id);
	
	List<Course> queryAllCourse();
	
	List<Course> queryAllCourseByCateId(Integer cateId);
	
	List<Course> queryAllCourseByUid(Integer uid);
	
	int getCourseNumberByUid(Integer uid);
	
	List<Course> GetRecentCourse();
	
	int UpdateCourseComment(Integer course_id,int comment_number);
	
	List<Course> getCollectList(Integer uid, String collect_table);
	
}
