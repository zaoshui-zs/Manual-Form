package com.manual.forum.service;

import java.util.List;

import com.manual.forum.pojo.Menu;

public interface MenuService {

	List<Menu> getMenuByUid(Integer uid);
}
