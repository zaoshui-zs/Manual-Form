package com.manual.forum.service;


import java.util.List;

import com.manual.forum.enums.SexEnum;
import com.manual.forum.pojo.Role;
import com.manual.forum.pojo.User;
import com.manual.forum.pojo.User_collect;

public interface UserService {

	public User addUser(User user);
	
	public User selectUserById(int id);
	
	public User selectUserByName(String name);
	
	public User register(User user);
	
	public User login(String username, String password);
	
	public int logout(int id);
	
	public int updateUser(User user);
	
	public int updatePassword(String password,Integer id);
	
	public int updatePhone(String phone,Integer id);
	
	public int updateUserInfo(User user);
	
	public String getUserNameById(Integer id);
	
	public String getSexName(SexEnum sex);
	
	public int collect(User_collect user_collect);
	
	public int cancel_collect(User_collect user_collect);
	
	public boolean getCollect(Integer uid,String collect_table,Integer collect_id);
	
	public int cancelCollect(User_collect user_collect);
	
	public List<Role> getUserRole(Integer uid);
	
	public int getAdminAccess(Integer uid);
}
