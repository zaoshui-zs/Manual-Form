package com.manual.forum.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.manual.forum.mapper.BlogMapper;
import com.manual.forum.service.BlogService;
@Service("blog")
public class BlogServiceImpl implements BlogService {

	@Autowired
	BlogMapper blogMapper;
	
	@Override
	public int getBlogNumberByUid(Integer uid) {
		// TODO Auto-generated method stub
		int res = blogMapper.getBlogNumberByUid(uid);
		return res;
	}

}
