package com.manual.forum.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.manual.forum.dto.UserComment;
import com.manual.forum.enums.CommonResponseEnum;
import com.manual.forum.mapper.CommentMapper;
import com.manual.forum.mapper.CourseMapper;
import com.manual.forum.pojo.Comment;
import com.manual.forum.service.CommentService;

@Service("comment")
public class CommentServiceImpl implements CommentService {

	@Autowired
	CommentMapper commentMapper;
	
	@Autowired
	CourseMapper courseMapper;
	
	@Override
	public Comment addComment(Comment comment) {
		// TODO Auto-generated method stub
		CommonResponseEnum.CONTENT_NOT_NULL.assertNotNull(comment);
		comment.setCreate_time(new Date());
		commentMapper.addComment(comment);
		commentMapper.UpdateCommentNumber(comment.getComment_table(), comment.getComment_row(), 1);
		return comment;
	}

	@Override
	public List<UserComment> getUserCommentList(String table, Integer table_id) {
		// TODO Auto-generated method stub
		List<UserComment> all = new ArrayList<>();
		all = commentMapper.GetUserCommentListByTableId(table, table_id);
        Map<Integer, UserComment> map = new HashMap<>();
        List<UserComment> result = new ArrayList<>();
        for (UserComment c : all) {
            if (c.getParent_id() == null) {
                result.add(c);
            }
            map.put(c.getId(), c);
        }
        for (UserComment c : all) {
            if (c.getParent_id() != null) {
            	UserComment parent = map.get(c.getParent_id());
                if (parent.getChild() == null) {
                    parent.setChild(new ArrayList<>());
                }
                parent.getChild().add(c);
            }
        }
        return result;
	}

	@Override
	public int getCommentNumber(String table, Integer table_id) {
		// TODO Auto-generated method stub
		int number = commentMapper.getCommentNumber(table, table_id);
		return number;
	}

}
