package com.manual.forum.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.manual.forum.dto.CategoryNum;
import com.manual.forum.mapper.CategoryMapper;
import com.manual.forum.pojo.Course_category;
import com.manual.forum.service.CourseCategoryService;
@Service("category")
public class CourseCategoryServiceImpl implements CourseCategoryService{

	@Autowired
	CategoryMapper categoryMapper;
	
	@Override
	public List<Course_category> GetAllCategory() {
		// TODO Auto-generated method stub
		List<Course_category> categoryList = categoryMapper.GetAllCategory();
		return categoryList;
	}

	@Override
	public List<CategoryNum> GetAllCategoryAndNum() {
		// TODO Auto-generated method stub
		int total = 0;
		List<CategoryNum> list = categoryMapper.GetAllCategoryAndNum();
		for (CategoryNum cn : list) {
			total += cn.getNum();
		}
		CategoryNum cn = new CategoryNum();
		cn.setId(0);
		cn.setCategory("全部");
		cn.setNum(total);
		list.add(0, cn);
		return list;
	}

	@Override
	public List<CategoryNum> GetPopularCategory() {
		// TODO Auto-generated method stub
		List<CategoryNum> list = categoryMapper.GetPopularCategory();
		return list;
	}

}
