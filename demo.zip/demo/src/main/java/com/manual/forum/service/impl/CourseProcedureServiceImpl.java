package com.manual.forum.service.impl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.manual.forum.enums.ArgumentResponseEnum;
import com.manual.forum.mapper.CourseProcedureMapper;
import com.manual.forum.pojo.Course_procedure;
import com.manual.forum.service.CourseProcedureService;

@Service
public class CourseProcedureServiceImpl implements CourseProcedureService{
	
	@Autowired
	CourseProcedureMapper cpMapper;

	@Override
	public int addCourseProcedure(Course_procedure cp) {
		// TODO Auto-generated method stub
		ArgumentResponseEnum.EMPTY_ARGS.assertNotNull(cp);
		int res = cpMapper.addCourseProcedure(cp);
		return res;
	}

	@Override
	public int addCourseProcedureList(String[] cpd, String[] cpp, Integer course_id) {
		int length = cpp.length;
		int result = 0;

		for(int i =0; i< length; i++) {	
			System.out.println("CouseProcedureServiceImpl：第"+i+"个步骤是"+cpd[i]);
			Course_procedure cp = new Course_procedure();
			cp.setCourse_id(course_id);

			System.out.println("CouseProcedureServiceImpl：图片路径是"+cpp[i]);
			cp.setProcedure_no(i+1);
			cp.setProcedure_photo(cpp[i]);
			cp.setProcedure_desc(cpd[i]);
			result += addCourseProcedure(cp);
		}
		return result;
	}

	@Override
	public List<Course_procedure> GetCourseProcedureListByCid(Integer course_id) {
		// TODO Auto-generated method stub
		List<Course_procedure> cpList = cpMapper.getCourseProcedureListByCid(course_id);
		return cpList;
	}
}
