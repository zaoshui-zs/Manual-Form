package com.manual.forum.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.manual.forum.enums.ArgumentResponseEnum;
import com.manual.forum.mapper.CourseMapper;
import com.manual.forum.pojo.Course;
import com.manual.forum.service.CourseService;

@Service("course")
public class CourseServiceImpl implements CourseService {
	
	@Autowired
	CourseMapper courseMapper;

	@Override
	public int addCourse(Course course) {
		// TODO Auto-generated method stub
		course.setCreate_time(new Date());
		ArgumentResponseEnum.EMPTY_ARGS.assertNotNull(course);
		int result = courseMapper.addCourse(course);
		return result;
	}

	@Override
	public List<Course> queryAllCourse() {
		// TODO Auto-generated method stub
		List<Course> res = courseMapper.queryAllCourse();
		return res;
	}

	@Override
	public List<Course> queryAllCourseByCateId(Integer cateId) {
		// TODO Auto-generated method stub
		if(cateId == 0) {
			List<Course> list = courseMapper.queryAllCourse();
			return list;
		}else {
			List<Course> list = courseMapper.queryAllCourseByCateId(cateId);
			return list;
		}
		
	}

	@Override
	public List<Course> GetRecentCourse() {
		// TODO Auto-generated method stub
		List<Course> list = courseMapper.getRecentCourse();
		return list;
	}

	@Override
	public Course GetCourseById(Integer id) {
		// TODO Auto-generated method stub
		Course course = courseMapper.GetCourseById(id);
		return course;
	}

	@Override
	public int UpdateCourseComment(Integer course_id, int comment_number) {
		// TODO Auto-generated method stub
		int res = courseMapper.UpdateCourseComment(course_id, comment_number);
		return res;
	}

	@Override
	public List<Course> queryAllCourseByUid(Integer uid) {
		// TODO Auto-generated method stub
		
		List<Course> list = courseMapper.queryAllCourseByUid(uid);
		return list;
	}

	@Override
	public int getCourseNumberByUid(Integer uid) {
		// TODO Auto-generated method stub
		int res = courseMapper.queryCourseNumberByUid(uid);
		return res;
	}

	@Override
	public List<Course> getCollectList(Integer uid, String collect_table) {
		// TODO Auto-generated method stub
		List<Course> list = courseMapper.getCollectList(uid, collect_table);
		return list;
	}

	public int getCollectNumber(Integer uid) {
		List<Course> list = courseMapper.getCollectList(uid, "course");
		return list.size();
	}

	public List<Course> search(String searchText) {
		// TODO Auto-generated method stub
		List<Course> list = courseMapper.search(searchText);
		return list;
	}
}
