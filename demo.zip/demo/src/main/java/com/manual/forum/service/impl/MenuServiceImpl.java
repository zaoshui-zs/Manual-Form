package com.manual.forum.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.manual.forum.mapper.MenuMapper;
import com.manual.forum.pojo.Menu;
import com.manual.forum.service.MenuService;

@Service("menu")
public class MenuServiceImpl implements MenuService {

	@Autowired
	MenuMapper menuMapper;
	
	@Override
	public List<Menu> getMenuByUid(Integer uid) {
		// TODO Auto-generated method stub
		List<Menu> all = menuMapper.getMenuByUid(uid);
		Map<Integer,Menu> map = new HashMap<>();
		List<Menu> result = new ArrayList<>();
		for(Menu m : all) {
			if(m.getParent_id() == 0) {
				result.add(m);
			}
			map.put(m.getId(), m);
		}
		for(Menu m : all) {
			if(m.getParent_id() != 0) {
				Menu parent = map.get(m.getParent_id());
				if(parent.getChild() == null) {
					parent.setChild(new ArrayList<>());
				}
				parent.getChild().add(m);
			}
		}
		return result;
	}

}
