package com.manual.forum.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.manual.forum.dto.ColumnComment;
import com.manual.forum.enums.OpTypeEnum;
import com.manual.forum.mapper.OperationLogDetailMapper;
import com.manual.forum.mapper.OperationLogMapper;
import com.manual.forum.pojo.Log_detail;
import com.manual.forum.pojo.Op_log;
import com.manual.forum.service.OperationLogService;
import com.manual.forum.util.HumpUtil;
import com.manual.forum.util.ToMapUtil;


@Service
public class OperationLogServiceImpl implements OperationLogService{
	@Autowired
	private OperationLogMapper operationLogMapper;
	@Autowired
	private OperationLogDetailMapper operationLogDetailMapper;
	
	@Override
	public void logForAdd(String professionalName, String logTableName,int opratorId, String operatorName, Object addedBean) {
		//基本处理
		if (addedBean==null) {
			return;
		}
		if (StringUtils.isBlank(logTableName)||StringUtils.isBlank(professionalName)||StringUtils.isBlank(opratorId+"")) {
			return;
		}
		Map<String, Object> map = ToMapUtil.toMap(addedBean);
		Set<String> beanKeySet = map.keySet();
		if (beanKeySet.size()==0) {
			return;
		}
		
		// 修改成异步操作,由此行以上结束处发送到队列!由以下开始处做消费!即可实现异步处理
		
		//表信息查询
		Map<String, Object> columnCommentMap = new HashMap<String, Object>();
		List<ColumnComment> columnCommentList = operationLogMapper.selectColumnCommentByTable(logTableName);
		for (ColumnComment cc : columnCommentList) {
			columnCommentMap.put(cc.getColumn(), cc.getComment());
		}
		
		//操作日志信息插入
		Op_log op = new Op_log();
		op.setName(professionalName);
		op.setTable_name(logTableName);
		op.setTable_id("");
		op.setOp_type(OpTypeEnum.ADD);
		op.setUid(opratorId);
		op.setOptor_name(operatorName);
		op.setOp_time(new Timestamp(System.currentTimeMillis()));
		operationLogMapper.insertOperationLog(op);
		
		List<Log_detail> opds = new ArrayList<Log_detail>();
		
		for (String key : beanKeySet) {
			String value = map.get(key)!=null?map.get(key).toString():"";
			key= HumpUtil.camelToUnderline(key);
			Log_detail opd = new Log_detail();
			opd.setClm_name(key);//字段名
			opd.setNew_string(value);//值
			opd.setClm_comment(columnCommentMap.get(key).toString());//字段备注 
			opd.setOld_string("");//原字段的值,添加操作无原值
			opd.setOp_log_id(op.getId());
			opds.add(opd);
		}
			
		if (!opds.isEmpty()) {
			operationLogDetailMapper.insertOperationLogDetail(opds);
		}
	}

	@Override
	public void logForDel(String professionalName, String logTableName,String primaryKeyId, int opratorId, String operatorName,Object beforDeledBean) {
		//基本处理
		if (beforDeledBean==null) {
			return;
		}
		if (StringUtils.isBlank(primaryKeyId)||StringUtils.isBlank(logTableName)||StringUtils.isBlank(professionalName)||StringUtils.isBlank(opratorId+"")) {
			return;
		}
		Map<String, Object> map = ToMapUtil.toMap(beforDeledBean);
		Set<String> beanKeySet = map.keySet();
		if (beanKeySet.size()==0) {
			return;
		}
		
		// 修改成异步操作,由此行以上结束处发送到队列!由以下开始处做消费!即可实现异步处理
		
		//表信息查询
		Map<String, Object> columnCommentMap = new HashMap<String, Object>();
		List<ColumnComment> columnCommentList = operationLogMapper.selectColumnCommentByTable(logTableName);
		for (ColumnComment cc : columnCommentList) {
			columnCommentMap.put(cc.getColumn(), cc.getComment());
		}
		
		//操作日志信息插入
		Op_log op = new Op_log();
		op.setName(professionalName);
		op.setTable_name(logTableName);
		op.setTable_id(primaryKeyId);
		op.setOp_type(OpTypeEnum.DELETE);
		op.setUid(opratorId);
		op.setOptor_name(operatorName);
		op.setOp_time(new Timestamp(System.currentTimeMillis()));
		operationLogMapper.insertOperationLog(op);
		
		List<Log_detail> opds = new ArrayList<Log_detail>();
		for (String key : beanKeySet) {
			String value = map.get(key)!=null?map.get(key).toString():"";
			key= HumpUtil.camelToUnderline(key);
			Log_detail opd = new Log_detail();
			opd.setClm_name(key);//字段名
			opd.setOld_string(value);//值
			opd.setClm_comment(columnCommentMap.get(key).toString());//字段备注 
			opd.setNew_string("");//新字段的值,删除操作无新值
			opd.setOp_log_id(op.getId());
			opds.add(opd);
		}
		if (!opds.isEmpty()) {
			operationLogDetailMapper.insertOperationLogDetail(opds);
		}
	}

	@Override
	public void logForUpd(String professionalName, String logTableName,String primaryKeyId, int opratorId, String operatorName,Object beforUpedBean, Object afterUpedBean) {
		//基本处理
		if (beforUpedBean==null||afterUpedBean==null) {
			return;
		}
		if (StringUtils.isBlank(primaryKeyId)||StringUtils.isBlank(logTableName)||StringUtils.isBlank(professionalName)||StringUtils.isBlank(opratorId+"")) {
			return;
		}
		Map<String, Object> map1 = ToMapUtil.toMap(beforUpedBean);
		Map<String, Object> map2 = ToMapUtil.toMap(afterUpedBean);
		Set<String> beanKeySet1 = map1.keySet();
		Set<String> beanKeySet2 = map2.keySet();
		if (beanKeySet1.size()==0||beanKeySet2.size()==0) {
			return;
		}
		
		// 修改成异步操作,由此行以上结束处发送到队列!由以下开始处做消费!即可实现异步处理
		
		//表信息查询
		Map<String, Object> columnCommentMap = new HashMap<String, Object>();
		List<ColumnComment> columnCommentList = operationLogMapper.selectColumnCommentByTable(logTableName);
		for (ColumnComment cc : columnCommentList) {
			columnCommentMap.put(cc.getColumn(), cc.getComment());
		}
		
		//操作日志信息插入
		Op_log op = new Op_log();
		op.setName(professionalName);
		op.setTable_name(logTableName);
		op.setTable_id(primaryKeyId);
		op.setOp_type(OpTypeEnum.UPDATE);
		op.setUid(opratorId);
		op.setOptor_name(operatorName);
		op.setOp_time(new Timestamp(System.currentTimeMillis()));
		operationLogMapper.insertOperationLog(op);
		
		List<Log_detail> opds = new ArrayList<Log_detail>();
		for (String key : beanKeySet1) {
			String valueOld = map1.get(key)!=null?map1.get(key).toString():"";
			String valueNew = map2.get(key)!=null?map2.get(key).toString():"";
			key= HumpUtil.camelToUnderline(key);
			Log_detail opd = new Log_detail();
			opd.setClm_name(key);//字段名
			opd.setOld_string(valueOld);//老值
			opd.setNew_string(valueNew);//新值
			opd.setClm_comment(columnCommentMap.get(key).toString());//字段备注 
			opd.setOp_log_id(op.getId());
			opds.add(opd);
		}
		if (!opds.isEmpty()) {
			operationLogDetailMapper.insertOperationLogDetail(opds);
		}
	}

}
