package com.manual.forum.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.manual.forum.enums.CommonResponseEnum;
import com.manual.forum.enums.SexEnum;
import com.manual.forum.mapper.UserMapper;
import com.manual.forum.pojo.Role;
import com.manual.forum.pojo.User;
import com.manual.forum.pojo.User_collect;
import com.manual.forum.service.UserService;

@Service("user")
public class UserServiceImpl implements UserService{
	
	@Autowired
	UserMapper userMapper;
	
//	@Autowired
//	OperationLogServiceImpl operationLogServiceImpl;

	private User u;
	
	@Override
	public User addUser(User user) {
		user.setGen_time(new Date());
		userMapper.addUser(user);
//		operationLogServiceImpl.logForAdd("添加用户", "user", 5, "admin", user);
		return user;
	}
	
	@Override
	public User selectUserById(int id) {
		u = userMapper.selectUserById(id);
		System.out.println("查询到的用户是"+u);
		CommonResponseEnum.USERNAME_NOT_FOUND.assertNotNull(u);
		return u;
	}

	@Override
	public User selectUserByName(String name) {
		u = userMapper.selectUserByName(name);
		CommonResponseEnum.USERNAME_NOT_FOUND.assertNotNull(u);
		return u;		
	}

	@Override
	public User register(User user) {
		String username = user.getUsername();
		String password = user.getPassword();
		String phone = user.getPhone();
		System.out.println("username="+username+"  password=="+password+"  phone="+phone);
		u = userMapper.selectUserByName(username);
		CommonResponseEnum.USERNAME_DUPLICATE.assertIsNull(u);
		User user1 = new User();
		user1.setUsername(username);
		user1.setPassword(password);
		user1.setPhone(phone);
		User result = addUser(user1);
		return result;
	}

	@Override
	public User login(String username, String password) {
		User user = userMapper.selectUserByName(username);
		CommonResponseEnum.USERNAME_NOT_FOUND.assertNotNull(user);
		CommonResponseEnum.PASSWORD_NOT.assertEquals(password, user.getPassword());
		user.setLast_login_time(user.getLogin_time());
		user.setLogin_time(new Date());
		userMapper.updateUser(user);
		return user;
	}
	
	@Override
	public int logout(int id) {
		User user = userMapper.selectUserById(id);
	    user.getLogin_time();
		int result = userMapper.updateUser(user);
		return result;
		
	}

	@Override
	public String getUserNameById(Integer id) {
		// TODO Auto-generated method stub
		String username = userMapper.getUserNameById(id);
		return username;
	}

	@Override
	public String getSexName(SexEnum sex) {
		// TODO Auto-generated method stub
		for(SexEnum s : SexEnum.values()) {
			if(s == sex) {
				return s.getSex();
			}
		}
		return null;
	}

	@Override
	public int updateUser(User user) {
		// TODO Auto-generated method stub
		int res = userMapper.updateUser(user);
		return res;
	}

	@Override
	public int updatePassword(String password, Integer id) {
		// TODO Auto-generated method stub
		int res = userMapper.updatePassword(password,id);
		return res;
	}

	@Override
	public int updatePhone(String phone, Integer id) {
		// TODO Auto-generated method stub
		int res = userMapper.updatePassword(phone,id);
		return res;
	}

	@Override
	public int updateUserInfo(User user) {
		// TODO Auto-generated method stub
		int res = userMapper.updateUserInfo(user);
		return res;
	}

	public int collect(User_collect user_collect) {
		// TODO Auto-generated method stub
		user_collect.setCreate_time(new Date());
		int res = userMapper.collect(user_collect);
		return res;
	}

	@Override
	public int cancel_collect(User_collect user_collect) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean getCollect(Integer uid, String collect_table, Integer collect_id) {
		// TODO Auto-generated method stub
		User_collect uc = userMapper.getCollect(uid, collect_table, collect_id);
		if(uc == null) {
			return false;
		}
		return true;
	}

	@Override
	public int cancelCollect(User_collect user_collect) {
		// TODO Auto-generated method stub
		int res = userMapper.cancelCollect(user_collect);
		return res;
	}

	public List<User> search(String searchText){
		List<User> list = userMapper.search(searchText);
		return list;
	}

	@Override
	public List<Role> getUserRole(Integer uid) {
		// TODO Auto-generated method stub
		List<Role> role = userMapper.getUserRole(uid);
		CommonResponseEnum.ADMIN_NOT.assertNotNull(role);
		return role;
	}

	@Override
	public int getAdminAccess(Integer uid) {
		// TODO Auto-generated method stub
		//System.out.println("userMapper.getAdminAccess(uid)=="+userMapper.getAdminAccess(uid));
		if(userMapper.getAdminAccess(uid)>0) {
			return 1;
		}
		return 0;
	}
}
