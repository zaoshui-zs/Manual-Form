package com.manual.forum.util;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

import org.springframework.util.ResourceUtils;
import org.springframework.web.multipart.MultipartFile;

public class PhotoUploadUtil {
	
	public String uploadPhoto(MultipartFile photo, String type) throws IOException {
		//判断用户是否上传了文件
		if(!photo.isEmpty()) {
			//文件上传的地址
            String path = ResourceUtils.getURL("classpath:").getPath()+"images/upload/"+type;
            path = path.replaceFirst("/target/classes", "/src/main/resources/static");
            String realPath = path.replace('/', '\\').substring(1,path.length());
            //用于查看路径是否正确
            //System.out.println(realPath);
            //获取文件名
            String fileName = photo.getOriginalFilename();
            //获取文件后缀名
            String suffixName = fileName.substring(fileName.lastIndexOf("."));
            //重新生成文件名
            fileName = UUID.randomUUID()+suffixName;
            //限制文件上传的类型
            String contentType = photo.getContentType();
            if("image/jpeg".equals(contentType) || "image/jpg".equals(contentType) ||
            		"image/png".equals(contentType)){
                File file = new File(realPath,fileName);
 
                //完成文件的上传
                photo.transferTo(file);
                String path01 = "/images/upload/"+type+"/"+fileName;
                System.out.println("PhotoUploadUtil:图片上传成功!path=="+path01);
                return path01;
            } else {
                System.out.println("PhotoUploadUtil:上传失败！");
                return "";
            }

            
		}else {
			System.out.println("PhotoUploadUtil:文件为空！");
            return "";
		}
        
	}

}
