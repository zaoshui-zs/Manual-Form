package com.manual.forum.util;

import java.beans.PropertyDescriptor;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;

public class ToMapUtil {

	@SuppressWarnings({ "unchecked"})
	public static <T> Map<String, Object> toMap(T bean) {
		if (bean instanceof Map) {
			return (Map<String, Object>)bean;
		}
		BeanWrapper beanWrapper = new BeanWrapperImpl(bean);
		Map<String, Object> map = new HashMap<String, Object>();
		PropertyDescriptor[] pds = beanWrapper.getPropertyDescriptors();
		for (PropertyDescriptor pd : pds) {
			if (!"class".equals(pd.getName())) {
				map.put(pd.getName(),beanWrapper.getPropertyValue(pd.getName()));
			}
		}
		return map;
	}
	
	public Map<String, String> toMap(String str1,String str2, String split){
		Map<String, String> map = new LinkedHashMap<String, String>();
		String[] s1 = StringUtils.splitPreserveAllTokens(str1,split);
		String[] s2 = StringUtils.splitPreserveAllTokens(str2,split);
		
		int len = s1.length;

		for(int i=0;i<len;i++) {
			//System.out.println("name:"+s1[i]+" num:"+s2[i]);
			if(s1[i] != null) {
				map.put(s1[i], s2[i]);
			}	
		}
		return map;
	}
}
