package com.example.demo;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.test.context.junit4.SpringRunner;

import com.manual.forum.DemoApplication;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = DemoApplication.class)
class DemoApplicationTests {

	private AnnotationConfigApplicationContext applicationContext2;

	@Test
	void contextLoads() {
		applicationContext2 = new AnnotationConfigApplicationContext(DemoApplication.class);
		String[] definitionNames = applicationContext2.getBeanDefinitionNames();
		for (String name : definitionNames) {
			System.out.println(name);
		}

	}

}
